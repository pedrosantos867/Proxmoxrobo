<?php

namespace modules\billmanagervps\classes\model;

use System\ObjectModel;

class Order extends ObjectModel {
    protected static $table = 'billmanagervps_orders';

}