{s}Unsuspend VPS order{/s}
Ваш сервер <?= ($order->id); ?> был разблокирован.